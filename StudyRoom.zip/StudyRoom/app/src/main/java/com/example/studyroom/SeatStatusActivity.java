package com.example.studyroom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.NameValuePair;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.entity.UrlEncodedFormEntity;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.message.BasicNameValuePair;

public class SeatStatusActivity extends AppCompatActivity {
static int count=46;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    
    DatabaseReference myRef = database.getReference();
    int error;
    Intent intent;
    Bundle bundle;
    String userid;

static String [] temp;
//static String CLIENT_KEY = "ImZ9qYaRj7mJyQTtnBYW";
//static String CLIENT_SECRET = "lHMaZtq8LQ";
//
//static String URL = "https://openapi.naver.com/v1/search/movie.json?query=기생충";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seatstatus);

        intent = getIntent();
        bundle = intent.getExtras();
        userid = bundle.getString("id");
//        String url = "https://google.com";

        myRef.child("Seat").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Log.d("자리번호", dataSnapshot.getValue().toString());
                    temp = dataSnapshot.getValue().toString().replaceAll("[A-z]", "").split(", ");
                    temp[temp.length - 1] = temp[temp.length - 1].replace("}", "");
                    Log.d("temp[0]", temp[0]);
                    Log.d("templength", String.valueOf(temp.length));
                    for (int i = 0; i < temp.length; i++) {
                        Log.d("temp[0]", temp[0]);
                        temp[i] = temp[i].replace("{","");
                        temp[i] = temp[i].substring(0,temp[i].indexOf("="));
                        Log.d("temp[i]", temp[i]);
                        Button usingseat = findViewById(Integer.parseInt(temp[i]));

                        usingseat.setBackgroundResource(R.drawable.grey);
                        usingseat.setText("");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("onCancelled", databaseError.toString());
            }
        });
    }
//            NetworkTask networkTask = new NetworkTask(url, null);
//            networkTask.execute();

        //

//        StringRequest request = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                Log.d("결과 확인", response);
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                // Error
//                Log.d("에러 출력", error.getMessage());
//            }
//        }) {
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                Map<String, String> headers = new HashMap<String, String>();
//                headers.put("X-Naver-Client-Id", CLIENT_KEY);
//                headers.put("X-Naver-Client-Secret", CLIENT_SECRET);
//                return headers;
//            }
//        };
//
//        MainActivity.requestQueue.add(request);
//    }

        public void OnclickedSeat(View v) {

            myRef.child("OnUser").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.getValue().toString().contains(userid)) {
                        Toast.makeText(SeatStatusActivity.this, "이용중인 좌석이 끝나지 않았습니다.", Toast.LENGTH_LONG).show();
                        finish();
                        startActivity(intent);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


                final String[] items = {"1시간", "2시간", "3시간", "4시간"};
                final Button Ib = (Button) v;
                final AlertDialog.Builder alert = new AlertDialog.Builder(SeatStatusActivity.this);

                Ib.setBackgroundResource(R.drawable.yellow);

                alert.setMessage("이 좌석을 사용하시겠습니까?").setPositiveButton("예", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        AlertDialog.Builder timealert = new AlertDialog.Builder(SeatStatusActivity.this);
                        timealert.setTitle("시간 설정");
                        timealert.setIcon(R.drawable.time);
                        timealert.setItems(items, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //누른 아이템의 시간만큼 데이터베이스에 정보 저장Log.d("예 누름", "1");
                                final String text = Ib.getText().toString();
                                final String id = String.valueOf(Ib.getId());


                                Ib.setBackgroundResource(R.drawable.grey);
                                Ib.setText("");

                                myRef.child("Seat").child(id).push().setValue(userid);//여기 마지막 부분을 사용자 학번으로 바꿔줘야함
                                myRef.child("OnUser").child(userid).push().setValue(userid);
                                CountDownTimer countDownTimer;
                                int time = Integer.parseInt(items[which].substring(0, 1)) * 1000 * 60;
                                countDownTimer = new CountDownTimer(time, time) {
                                    @Override
                                    public void onTick(long millisUntilFinished) {

                                    }

                                    @Override
                                    public void onFinish() {
                                        String id = String.valueOf(Ib.getId());
                                        Ib.setClickable(true);//클릭 활성화
                                        Ib.setBackgroundResource(R.drawable.green);//다시 청록색
                                        Ib.setText(text);//좌석에 다시 번호 표시

                                        //현재 데이터베이스의 남은 좌석 수로 초기화
                                        myRef.child("Seat").child(id).removeValue();
                                        myRef.child("OnUser").child(userid).setValue(null);
                                    }
                                }.start();

                                Ib.setClickable(false);
                                dialog.cancel();
                            }
                        });
                        timealert.show();
                    }
                }).setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Ib.setBackgroundResource(R.drawable.green);
                        dialog.cancel();
                    }
                });
                alert.show();

        }
    public void OnclickedReport(View v){

        AlertDialog.Builder alert = new AlertDialog.Builder(SeatStatusActivity.this);
        alert.setTitle("사용자 신고")
        .setMessage("신고하려는 사용자의 좌석 번호를 입력하세요.").setCancelable(false);
        final EditText et = new EditText(SeatStatusActivity.this);
        et.setHint("ex. 17");
        et.setWidth(50);
        alert.setView(et);
        alert.setIcon(R.drawable.report);
        alert.setPositiveButton("신고", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {//신고를 누르면
               final String seatnumber = et.getText().toString();
                Log.d("seatnumber",seatnumber);
                final int seatid = getResources().getIdentifier("seat"+seatnumber,"id",getPackageName());
                myRef.child("Seat").child(seatid+"").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.getValue()!=null) {
                            myRef.child("baduser").push().setValue(dataSnapshot.getValue().toString().substring(dataSnapshot.getValue().toString().indexOf("=")+1).replace("}",""));
                            Toast.makeText(SeatStatusActivity.this,"신고가 접수되었습니다",Toast.LENGTH_LONG).show();
                        }
                        else    {
                            Log.d("seatnumber",seatnumber);
                            Toast.makeText(SeatStatusActivity.this,"사용자 학번을 찾을 수 없습니다.",Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        })

        .setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        }).show();
    }


    public void OnclickedRefresh(View v){
        Intent intent = getIntent();
        finish();
        startActivity(intent);

    }





//        HttpClient client = new DefaultHttpClient();
//        HttpPost post = new HttpPost("https://google.com");
//
//        ArrayList<NameValuePair> nameValues = new ArrayList<NameValuePair>();
//
//        try{
//            nameValues.add(new BasicNameValuePair("seatnumber", URLDecoder.decode(String.valueOf(Ib.getId()), "UTF-8")));
//            post.setEntity(new UrlEncodedFormEntity(nameValues,"UTF-8"));
//        } catch (UnsupportedEncodingException e) {
//            Log.e("Insert Log", e.toString());
//        }

//        try{
//            HttpResponse response = client.execute(post);
//            Log.i("Insert Log", "response.getStatusCode:" + response.getStatusLine().getStatusCode());
//        }  catch (IOException e) {
//            e.printStackTrace();
//        }


    public void OnclickedLostItem(View v){
        Intent intent = new Intent(this, MainBoard.class);
        startActivity(intent);

    }
//    public class NetworkTask extends AsyncTask<Void, Void, String> {
//
//        private String url;
//        private ContentValues values;
//
//        public NetworkTask(String url, ContentValues values) {
//
//            this.url = url;
//            this.values = values;
//        }
//
////        @Override
////        protected String doInBackground(Void... voids) {
////            // 통신 날릴 메소드를 만들자
//////            RequestHttpURLConnection a = new RequestHttpURLConnection();
//////
////        String abc = a.request("sdkaksd", params);
////           return abc;
////        }
//
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//            //progress bar를 보여주는 등등의 행위
//        }
//
//
//        @Override
//        protected void onPostExecute(String s) {
//            super.onPostExecute(s);
//
//            // UI Thread
//
//
//            //doInBackground()로 부터 리턴된 값이 onPostExecute()의 매개변수로 넘어오므로 s를 출력한다.
//
//        }
//    }
}

